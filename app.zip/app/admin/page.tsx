"use client";
import { useEffect, useState } from "react";
import { BlogPost } from "@/lib/blog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import dynamic from "next/dynamic";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Plus, Edit, Trash2, Save, X, FileText, Calendar, User } from "lucide-react";
const MarkdownEditor = dynamic(() => import("react-simplemde-editor"), { ssr: false });

export default function AdminPage() {
	const [form, setForm] = useState<Partial<BlogPost>>({
		title: "",
		slug: "",
		date: new Date().toISOString().slice(0, 10),
		excerpt: "",
		coverImage: "",
		author: "",
		categories: [],
		tags: [],
		metaTitle: "",
		metaDescription: "",
		canonicalUrl: "",
		isIndexed: false,
		content: "",
	});

	const [posts, setPosts] = useState<BlogPost[]>([]);
	const [editingSlug, setEditingSlug] = useState<string | null>(null);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const [success, setSuccess] = useState<string | null>(null);

	async function loadPosts() {
		setLoading(true);
		setError(null);
		try {
			const res = await fetch("/api/posts");
			if (!res.ok) throw new Error("Failed to load posts");
			const data = await res.json();
			setPosts(data);
		} catch (e: any) {
			setError(e?.message ?? "Failed to load posts");
		} finally {
			setLoading(false);
		}
	}

	useEffect(() => {
		loadPosts();
	}, []);

	function resetForm() {
		setForm({
			title: "",
			slug: "",
			date: new Date().toISOString().slice(0, 10),
			excerpt: "",
			coverImage: "",
			author: "",
			categories: [],
			tags: [],
			metaTitle: "",
			metaDescription: "",
			content: "",
		});
		setEditingSlug(null);
		setSuccess(null);
		setError(null);
	}

	function showSuccess(message: string) {
		setSuccess(message);
		setTimeout(() => setSuccess(null), 3000);
	}

	async function handleSubmit() {
		setLoading(true);
		setError(null);
		setSuccess(null);

		try {
			if (editingSlug) {
				const res = await fetch(`/api/posts/${editingSlug}`, {
					method: "PUT",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify(form),
				});
				if (!res.ok) throw new Error((await res.json()).error ?? "Failed to update");
				showSuccess("Post updated successfully!");
			} else {
				const res = await fetch("/api/posts", {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify(form),
				});
				if (!res.ok) throw new Error((await res.json()).error ?? "Failed to create");
				showSuccess("Post created successfully!");
			}
			await loadPosts();
			resetForm();
		} catch (e: any) {
			setError(e?.message ?? `Failed to ${editingSlug ? "update" : "create"} post`);
		} finally {
			setLoading(false);
		}
	}

	async function handleDelete(slug: string) {
		if (!confirm("Are you sure you want to delete this post? This action cannot be undone.")) {
			return;
		}

		setLoading(true);
		setError(null);
		try {
			const res = await fetch(`/api/posts/${slug}`, { method: "DELETE" });
			if (!res.ok) throw new Error((await res.json()).error ?? "Failed to delete");
			await loadPosts();
			if (editingSlug === slug) resetForm();
			showSuccess("Post deleted successfully!");
		} catch (e: any) {
			setError(e?.message ?? "Failed to delete post");
		} finally {
			setLoading(false);
		}
	}

	function startEdit(p: BlogPost) {
		setEditingSlug(p.slug);
		setForm(p);
		setError(null);
		setSuccess(null);
		// Scroll to form
		window.scrollTo({ top: 0, behavior: "smooth" });
	}

	return (
		<div className="container mx-auto px-4 py-8">
			<div className="flex items-center justify-between mb-8">
				<div>
					<h1 className="text-3xl font-bold text-gray-900">Blog Admin</h1>
					<p className="text-gray-600 mt-2">Manage your blog posts and content</p>
				</div>
				<Button onClick={resetForm} variant="outline" className="flex items-center gap-2">
					<Plus className="h-4 w-4" />
					New Post
				</Button>
			</div>

			{/* Notifications */}
			{error && (
				<Alert variant="destructive" className="mb-6">
					<AlertDescription>{error}</AlertDescription>
				</Alert>
			)}
			{success && (
				<Alert className="mb-6 bg-green-50 border-green-200">
					<AlertDescription className="text-green-800">{success}</AlertDescription>
				</Alert>
			)}

			<Tabs defaultValue="edit" className="space-y-6">
				<TabsList className="grid w-full grid-cols-2">
					<TabsTrigger value="edit" className="flex items-center gap-2">
						<FileText className="h-4 w-4" />
						{editingSlug ? "Edit Post" : "Create Post"}
					</TabsTrigger>
					<TabsTrigger value="posts" className="flex items-center gap-2">
						<FileText className="h-4 w-4" />
						All Posts ({posts.length})
					</TabsTrigger>
				</TabsList>

				<TabsContent value="edit">
					<Card>
						<CardHeader>
							<CardTitle>{editingSlug ? "Edit Blog Post" : "Create New Blog Post"}</CardTitle>
							<CardDescription>
								{editingSlug
									? "Update your existing blog post content"
									: "Fill in the details to create a new blog post"}
							</CardDescription>
						</CardHeader>
						<CardContent className="space-y-6">
							<div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
								{/* Left Column - Basic Info */}
								<div className="space-y-4">
									<div className="grid grid-cols-2 gap-4">
										<div className="space-y-2">
											<label className="text-sm font-medium text-gray-700">Title *</label>
											<Input
												placeholder="Enter post title"
												value={form.title ?? ""}
												onChange={(e) => setForm({ ...form, title: e.target.value })}
											/>
										</div>
										<div className="space-y-2">
											<label className="text-sm font-medium text-gray-700">Slug *</label>
											<Input
												placeholder="URL-friendly slug"
												value={form.slug ?? ""}
												onChange={(e) => setForm({ ...form, slug: e.target.value })}
											/>
										</div>
									</div>

									<div className="grid grid-cols-2 gap-4">
										<div className="space-y-2">
											<label className="text-sm font-medium text-gray-700">Date</label>
											<Input
												type="date"
												value={form.date ?? ""}
												onChange={(e) => setForm({ ...form, date: e.target.value })}
											/>
										</div>
										<div className="space-y-2">
											<label className="text-sm font-medium text-gray-700">Author</label>
											<Input
												placeholder="Author name"
												value={form.author ?? ""}
												onChange={(e) => setForm({ ...form, author: e.target.value })}
											/>
										</div>
									</div>

                                    <div className="space-y-2">
                                        <label className="text-sm font-medium text-gray-700">Cover Image</label>
                                        <Input
                                            placeholder="https://example.com/image.jpg"
                                            value={form.coverImage ?? ""}
                                            onChange={(e) => setForm({ ...form, coverImage: e.target.value })}
                                        />
                                        <input
                                            type="file"
                                            accept="image/*"
                                            onChange={async (e) => {
                                                const file = e.target.files?.[0];
                                                if (!file) return;
                                                const fd = new FormData();
                                                fd.append("file", file);
                                                const res = await fetch("/api/upload", { method: "POST", body: fd });
                                                const data = await res.json();
                                                if (res.ok && data.url) setForm({ ...form, coverImage: data.url });
                                            }}
                                        />
                                        {form.coverImage && (
                                            <div className="mt-2">
                                                <img
                                                    src={form.coverImage}
                                                    alt="Cover preview"
                                                    className="h-20 w-full object-cover rounded border"
                                                />
                                            </div>
                                        )}
                                    </div>

									<div className="space-y-2">
										<label className="text-sm font-medium text-gray-700">Categories</label>
										<Input
											placeholder="Technology, Web Development, Design"
											value={(form.categories ?? []).join(", ")}
											onChange={(e) =>
												setForm({
													...form,
													categories: e.target.value.split(",").map((s) => s.trim()).filter(Boolean),
												})
											}
										/>
									</div>

									<div className="space-y-2">
										<label className="text-sm font-medium text-gray-700">Tags</label>
										<Input
											placeholder="react, nextjs, tutorial"
											value={(form.tags ?? []).join(", ")}
											onChange={(e) =>
												setForm({
													...form,
													tags: e.target.value.split(",").map((s) => s.trim()).filter(Boolean),
												})
											}
										/>
									</div>
								</div>

								{/* Right Column - Content & SEO */}
								<div className="space-y-4">
									<div className="space-y-2">
										<label className="text-sm font-medium text-gray-700">Excerpt</label>
										<Textarea
											placeholder="Brief description of the post"
											value={form.excerpt ?? ""}
											onChange={(e) => setForm({ ...form, excerpt: e.target.value })}
											rows={3}
										/>
									</div>

                                    <div className="space-y-2">
                                        <label className="text-sm font-medium text-gray-700">Content (Markdown)</label>
                                        <MarkdownEditor value={form.content ?? ""} onChange={(v: string) => setForm({ ...form, content: v })} />
                                    </div>

                                    <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
										<h4 className="font-medium text-sm text-gray-900">SEO Settings</h4>
										<div className="space-y-2">
											<label className="text-sm font-medium text-gray-700">Meta Title</label>
											<Input
												placeholder="SEO title for search engines"
												value={form.metaTitle ?? ""}
												onChange={(e) => setForm({ ...form, metaTitle: e.target.value })}
											/>
										</div>
										<div className="space-y-2">
											<label className="text-sm font-medium text-gray-700">Meta Description</label>
											<Textarea
												placeholder="SEO description for search engines"
												value={form.metaDescription ?? ""}
												onChange={(e) => setForm({ ...form, metaDescription: e.target.value })}
												rows={2}
											/>
										</div>
                                        <div className="space-y-2">
                                            <label className="text-sm font-medium text-gray-700">Canonical URL</label>
                                            <Input
                                                placeholder="https://yourdomain.com/blog/your-post"
                                                value={form.canonicalUrl ?? ""}
                                                onChange={(e) => setForm({ ...form, canonicalUrl: e.target.value })}
                                            />
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <input id="isIndexed" type="checkbox" checked={Boolean(form.isIndexed)} onChange={(e) => setForm({ ...form, isIndexed: e.target.checked })} />
                                            <label htmlFor="isIndexed" className="text-sm">Index this post (unchecked = noindex)</label>
                                        </div>
									</div>
								</div>
							</div>

							<div className="flex gap-3 pt-4 border-t">
								<Button
									onClick={handleSubmit}
									disabled={loading || !form.title || !form.slug}
									className="flex items-center gap-2"
								>
									{loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
									{editingSlug ? "Update Post" : "Create Post"}
								</Button>
								{editingSlug && (
									<Button variant="outline" onClick={resetForm} disabled={loading} className="flex items-center gap-2">
										<X className="h-4 w-4" />
										Cancel
									</Button>
								)}
							</div>
						</CardContent>
					</Card>
				</TabsContent>

				<TabsContent value="posts">
					<Card>
						<CardHeader>
							<CardTitle>Blog Posts</CardTitle>
							<CardDescription>Manage your existing blog posts</CardDescription>
						</CardHeader>
						<CardContent>
							{loading ? (
								<div className="flex justify-center py-8">
									<Loader2 className="h-8 w-8 animate-spin text-gray-400" />
								</div>
							) : posts.length === 0 ? (
								<div className="text-center py-8 text-gray-500">
									<FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
									<p>No blog posts found. Create your first post!</p>
								</div>
							) : (
								<div className="space-y-4">
									{posts.map((post) => (
										<div
											key={post.slug}
											className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
										>
											<div className="flex-1 min-w-0">
												<div className="flex items-center gap-3 mb-2">
													<h3 className="font-semibold text-gray-900 truncate">{post.title}</h3>
													{editingSlug === post.slug && (
														<Badge variant="secondary" className="bg-blue-100 text-blue-800">
															Editing
														</Badge>
													)}
												</div>
												<div className="flex items-center gap-4 text-sm text-gray-600">
													<div className="flex items-center gap-1">
														<Calendar className="h-3 w-3" />
														<span>{new Date(post.date).toLocaleDateString()}</span>
													</div>
													{post.author && (
														<div className="flex items-center gap-1">
															<User className="h-3 w-3" />
															<span>{post.author}</span>
														</div>
													)}
													{post.categories && post.categories.length > 0 && (
														<div className="flex items-center gap-1">
															<span>Categories: {post.categories.join(", ")}</span>
														</div>
													)}
												</div>
											</div>
											<div className="flex items-center gap-2 ml-4">
												<Button
													size="sm"
													variant="outline"
													onClick={() => startEdit(post)}
													disabled={loading}
													className="flex items-center gap-1"
												>
													<Edit className="h-3 w-3" />
													Edit
												</Button>
												<Button
													size="sm"
													variant="destructive"
													onClick={() => handleDelete(post.slug)}
													disabled={loading}
													className="flex items-center gap-1"
												>
													<Trash2 className="h-3 w-3" />
													Delete
												</Button>
											</div>
										</div>
									))}
								</div>
							)}
						</CardContent>
					</Card>
				</TabsContent>
			</Tabs>
		</div>
	);
}