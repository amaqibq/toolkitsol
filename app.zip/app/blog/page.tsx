import Link from "next/link";
import { getAllPosts, filterPosts, paginatePosts, getAllCategories } from "@/lib/blog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const dynamic = "force-static";

type SearchParams = {
	page?: string;
	q?: string;
	category?: string;
};

export default function BlogPage({ searchParams }: { searchParams: SearchParams }) {
	const page = Number(searchParams?.page ?? 1);
	const q = searchParams?.q ?? "";
	const category = searchParams?.category ?? "all";

	const all = getAllPosts();
	const categories = getAllCategories(all);
	const filtered = filterPosts(all, { query: q, category: category === "all" ? "" : category });
	const { items, totalPages } = paginatePosts(filtered, page, 10);

	return (
		<div className="container mx-auto px-4 py-10">
			<h1 className="text-3xl font-bold mb-6">Blog</h1>
			<form className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
				<Input name="q" defaultValue={q} placeholder="Search posts..." />
				<Select name="category" defaultValue={category || "all"}>
					<SelectTrigger>
						<SelectValue placeholder="All categories" />
					</SelectTrigger>
					<SelectContent>
						<SelectItem value="all">All</SelectItem>
						{categories.map((c) => (
							<SelectItem key={c} value={c}>
								{c}
							</SelectItem>
						))}
					</SelectContent>
				</Select>
				<button className="btn btn-primary border px-4 py-2 rounded" type="submit">Apply</button>
			</form>

			<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
				{items.map((post) => (
					<Card key={post.slug}>
						<CardHeader>
							<CardTitle>
								<Link href={`/blog/${post.slug}`}>{post.title}</Link>
							</CardTitle>
						</CardHeader>
						<CardContent>
							{post.coverImage ? (
								// eslint-disable-next-line @next/next/no-img-element
								<img src={post.coverImage} alt="" className="w-full h-40 object-cover rounded mb-3" />
							) : null}
							<p className="text-sm text-muted-foreground mb-2">{new Date(post.date).toLocaleDateString()}</p>
							<p className="line-clamp-3">{post.excerpt}</p>
						</CardContent>
					</Card>
				))}
			</div>

			{totalPages > 1 && (
				<div className="flex items-center justify-center gap-2 mt-10">
					{Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => {
						const params = new URLSearchParams();
						if (q) params.set("q", q);
						if (category && category !== "all") params.set("category", category);
						params.set("page", String(p));
						return (
							<Link key={p} href={`/blog?${params.toString()}`} className={`px-3 py-1 border rounded ${p === page ? "bg-primary text-primary-foreground" : ""}`}>
								{p}
							</Link>
						);
					})}
				</div>
			)}
		</div>
	);
}



