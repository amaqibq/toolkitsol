import { readPostBySlug, getAllPostSlugs } from "@/lib/blog";
import { notFound } from "next/navigation";
import { Metadata } from "next";
import Link from "next/link";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import type { BlogPost } from "@/lib/blog";

export const dynamic = "force-static";

type Params = { slug: string };

export async function generateStaticParams() {
	return getAllPostSlugs().map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
	const post = readPostBySlug(params.slug);
	if (!post) return {};
	const url = `${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/blog/${post.slug}`;
	return {
		title: post.metaTitle ?? post.title,
		description: post.metaDescription ?? post.excerpt,
		alternates: post.canonicalUrl ? { canonical: post.canonicalUrl } : undefined,
		robots: { index: Boolean(post.isIndexed), follow: Boolean(post.isIndexed) },
		openGraph: {
			title: post.metaTitle ?? post.title,
			description: post.metaDescription ?? post.excerpt,
			url,
			images: post.coverImage ? [{ url: post.coverImage }] : undefined,
			type: "article",
		},
		twitter: {
			card: post.coverImage ? "summary_large_image" : "summary",
			title: post.metaTitle ?? post.title,
			description: post.metaDescription ?? post.excerpt,
			images: post.coverImage ? [post.coverImage] : undefined,
		},
	};
}

export default function BlogPostPage({ params }: { params: Params }) {
	const post = readPostBySlug(params.slug);
	if (!post) return notFound();

	return (
		<article className="container mx-auto px-4 py-10 prose dark:prose-invert">
			<nav className="mb-6 text-sm">
				<Link href="/blog" className="text-muted-foreground hover:underline">← Back to blog</Link>
			</nav>
			<h1>{post.title}</h1>
			<p className="text-sm text-muted-foreground">{new Date(post.date).toLocaleDateString()}</p>
			{post.coverImage ? (
				// eslint-disable-next-line @next/next/no-img-element
				<img src={post.coverImage} alt="" className="w-full h-auto rounded my-6" />
			) : null}

			<ReactMarkdown
				remarkPlugins={[remarkGfm]}
				rehypePlugins={[rehypeHighlight]}
				components={{
					img: ({ node, ...props }) => (
						// eslint-disable-next-line @next/next/no-img-element
						<img {...props} className="max-w-full h-auto rounded" />
					),
				}}
			>
				{post.content}
			</ReactMarkdown>

			{/* JSON-LD Schema */}
			<script
				type="application/ld+json"
				dangerouslySetInnerHTML={{ __html: JSON.stringify(buildPostJsonLd(post)) }}
			/>
		</article>
	);
}

function buildPostJsonLd(post: BlogPost) {
	const url = `${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/blog/${post.slug}`;
	return {
		"@context": "https://schema.org",
		"@type": "BlogPosting",
		headline: post.title,
		datePublished: post.date,
		dateModified: post.date,
		author: post.author ? { "@type": "Person", name: post.author } : undefined,
		image: post.coverImage ? [post.coverImage] : undefined,
		description: post.metaDescription ?? post.excerpt,
		url,
		mainEntityOfPage: { "@type": "WebPage", "@id": url },
	};
}


